This folder stores project source files for the development team.
