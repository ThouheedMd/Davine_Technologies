#!/bin/bash
# Displays basic system information
echo "Hostname : $(hostname)"
echo "Date     : $(date)"
echo "Uptime   : $(uptime -p)"
echo "IP Addr  : $(hostname -I)"
